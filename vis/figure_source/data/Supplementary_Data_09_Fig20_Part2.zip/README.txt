Supplementary Data for Supplementary Figure 20
==============================================

Manuscript reference: NENERGY-24102996D
Display item: Supplementary Figure 20

Package structure
-----------------
- data/: numerical data and figure metadata.
- code/: plotting code included in this Supplementary Data package.
- utils/: shared deterministic model utilities used by the plotting code.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
- Supplementary Figure 20: Statistics use aligned scenarios and reference-country internal AC lines; map tables contain selected illustrative heatwave snapshots for the represented single-country and joint-grid configurations.

Reproduction
------------
  python code/merge_supplementary_fig20_parts.py --part-a data/Supplementary_Fig_20_france_cross_border/data/statistics/line_temperature_observations_load_growth_1.01.csv --part-b data/Supplementary_Fig_20_france_cross_border/data/statistics/line_temperature_observations_load_growth_1.03.csv --output data/Supplementary_Fig_20_france_cross_border/data/statistics/line_temperature_observations.csv
  python code/plot_si_distribution_panels.py --source-root data --output-root reproduced_distribution_artwork

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Shared Supplementary Figure 20 files and line-temperature observations for load growth 1.03. Extract Parts 1 and 2 into the same directory, merge the two line-temperature tables using the recorded command and then run the figure command.
