"""Merge the two row-partitioned Supplementary Figure 20 tables."""
import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--part-a", type=Path, required=True)
    parser.add_argument("--part-b", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = None
    with args.output.open("w", newline="", encoding="utf-8") as target:
        writer = None
        for source in (args.part_a, args.part_b):
            with source.open("r", newline="", encoding="utf-8") as handle:
                reader = csv.DictReader(handle)
                if reader.fieldnames is None:
                    raise ValueError(f"Missing CSV header: {source}")
                if fieldnames is None:
                    fieldnames = reader.fieldnames
                    writer = csv.DictWriter(target, fieldnames=fieldnames, lineterminator="\n")
                    writer.writeheader()
                elif reader.fieldnames != fieldnames:
                    raise ValueError("The split tables have different columns")
                writer.writerows(reader)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
