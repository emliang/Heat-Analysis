Source Data for Extended Data Figure 1
======================================

Manuscript reference: NENERGY-24102996D
Display item: Extended Data Figure 1

Package structure
-----------------
- data/: numerical data and figure metadata.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
Load shedding is a scenario observation; line temperature and available capacity are scenario-line observations over 480 scenarios and 442 represented AC branches.

Reproduction
------------
The plotting code is maintained in the project repository (https://emliang.github.io/Heat-Analysis/). Before running the command, set HEAT_ANALYSIS_ROOT to the root of a local checkout, for example:

  export HEAT_ANALYSIS_ROOT=/path/to/HeatAnalysis

  conda run --no-capture-output -n HEAT python "${HEAT_ANALYSIS_ROOT:?Set HEAT_ANALYSIS_ROOT to the HeatAnalysis checkout}/nature_final_materials/publication_pipeline/code/plotting/plot_extended_data_figures.py" --source-dir data --figure 1 --output-pdf reproduced/Extended_Data_Fig_1.pdf --output-png reproduced/Extended_Data_Fig_1.png

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Source Data for Extended Data Fig. 1 - Spanish spatiotemporal stress
=====================================================================

Scope and statistical units
---------------------------
The independent simulation unit is one projected hourly heatwave scenario.
All 480 exported scenarios have solver_status=1; no scenario is excluded. The
represented Spanish grid contains 442 AC branches.

Panels a and c are grouped by hour: n_s=120 scenarios, n_l=442 branches and
n_obs=53,040 scenario-branch observations per hour. Panels b and d are grouped
by year: n_s=96, n_l=442 and n_obs=42,432 per year. Panels e and f contain one
load-shedding value per scenario (n=120 per hour and n=96 per year).

Boxes span Q1-Q3, centre lines are medians, whiskers are the most extreme
observations within 1.5 times the interquartile range, violin widths show a
Gaussian kernel-density estimate of all observations, and dark-red points show
means. Individual values outside the whiskers are not drawn separately but
remain in the violin and Source Data. sd_ddof_0 is the population standard
deviation. No statistical hypothesis test is applied.

Files, columns and units
------------------------
- ExtendedDataFig1_scenario_observations.csv: scenario_id; projected and
  historical dates; future_year and future_hour; air_temperature_c (degrees C),
  wind_speed_m_per_s, solar_irradiance_w_per_m2, load_gw,
  load_shedding_percent and solver_status. One row per scenario; supports e-f.
- ExtendedDataFig1_scenario_branch_observations.csv.gz: scenario_id,
  branch_index, available_capacity_percent_of_nominal, line_temperature_c and
  solver_status. One row per scenario-branch observation; supports a-d.
- ExtendedDataFig1_distribution_summary.csv: panel/group identifiers,
  observation_unit, n_scenarios, n_observations, mean, sd_ddof_0, minimum, Q1,
  median, Q3, maximum, whiskers and the number of values outside the whiskers.
- ExtendedDataFig1_plot_metadata.json: plotting settings and statistical
  encoding. input_provenance.csv and manifest.json record input/output hashes.

Grouping and filters
--------------------
Panels a, c and e group all 480 scenarios by
future_hour; panels b, d and f group it by future_year. No simulation is rerun
and no additional value filter is applied. Spatial grid maps are displayed and
delivered separately as Extended Data Fig. 2.

Source record pattern
---------------------
The exporter consumes the verified Supplementary Fig. 17 compact component,
which traces the active records under models/ES/ppc/<future-date>/*_results.npy
and the corresponding weather record. Exact source paths and SHA-256 hashes are
listed in input_provenance.csv and manifest.json.

Export:
  conda run --no-capture-output -n HEAT python nature_final_materials/publication_pipeline/code/exporters/export_extended_data_figures.py --pipeline-root nature_final_materials/publication_pipeline --figure 1
Plot:
  conda run --no-capture-output -n HEAT python nature_final_materials/publication_pipeline/code/plotting/plot_extended_data_figures.py --pipeline-root nature_final_materials/publication_pipeline --figure 1
