Source Data for Main Figure 1
=============================

Manuscript reference: NENERGY-24102996D
Display item: Main Figure 1

Package structure
-----------------
- data/: numerical data and figure metadata.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
Panels a-c contain deterministic heat-balance values; panel d contains represented network, weather-cell and selected line-segment records for one displayed heatwave scenario.

Reproduction
------------
The plotting code is maintained in the project repository (https://emliang.github.io/Heat-Analysis/). Before running the command, set HEAT_ANALYSIS_ROOT to the root of a local checkout, for example:

  export HEAT_ANALYSIS_ROOT=/path/to/HeatAnalysis

  conda run --no-capture-output -n HEAT python "${HEAT_ANALYSIS_ROOT:?Set HEAT_ANALYSIS_ROOT to the HeatAnalysis checkout}/nature_final_materials/publication_pipeline/code/plotting/plot_main_figure_01_panel_d_sources.py" --source-dir data --output-dir reproduced/Fig_1d_components

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Main Figure 1 Source Data and provenance

Panels a-c are deterministic IEEE Std 738 heat-balance calculations. The
conductor parameters, weather parameters and axis-generation rules are stored
as compact CSV files. Dense mechanically generated matrices are reconstructed
in memory by the plotting code and are not duplicated in this ZIP.

Panel d uses the represented 75% clustered Spanish network and the selected
2026-07-29 14:00 heatwave weather field. The package stores the compact plotted
network, temperature grid and eight segment records for the 130.6-km selected
line. The source-component plotting script reconstructs the map, line inset and
both colour bars. The editable PowerPoint is retained for the final composition,
and the current manuscript PNG remains the display asset used in the assembled
figure.

No grid simulation is rerun by this package.
