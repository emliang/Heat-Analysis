Source Data for Main Figure 3
=============================

Manuscript reference: NENERGY-24102996D
Display item: Main Figure 3

Package structure
-----------------
- data/: numerical data and figure metadata.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
Panels a-b contain scenario-line observations; panels c-d contain scenario-method observations over the common set of 480 projected hourly heatwave scenarios.

Reproduction
------------
The plotting code is maintained in the project repository (https://emliang.github.io/Heat-Analysis/). Before running the command, set HEAT_ANALYSIS_ROOT to the root of a local checkout, for example:

  export HEAT_ANALYSIS_ROOT=/path/to/HeatAnalysis

  conda run --no-capture-output -n HEAT python "${HEAT_ANALYSIS_ROOT:?Set HEAT_ANALYSIS_ROOT to the HeatAnalysis checkout}/nature_final_materials/publication_pipeline/code/plotting/plot_main_figure_03.py" --source-dir data --pdf reproduced/Fig_3.pdf --png reproduced/Fig_3.png

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Source Data for main Figure 3

Fig3ab_scenario_line_observations.csv.gz contains the complete 480-scenario by 442-line populations for available capacity and line temperature in panels a and b.
Fig3cd_scenario_observations.csv contains the complete 480-scenario populations for load shedding and running time in panels c and d.
All four OPF methods are compared over the same 480 scenarios. The exporter consumes the verified Supplementary Figure 16 component and does not rerun OPF or duplicate upstream NPY records.
