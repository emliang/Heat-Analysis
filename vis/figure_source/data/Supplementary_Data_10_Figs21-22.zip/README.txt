Supplementary Data for Supplementary Figure 21, Supplementary Figure 22
=======================================================================

Manuscript reference: NENERGY-24102996D
Display item: Supplementary Figure 21, Supplementary Figure 22

Package structure
-----------------
- data/: numerical data and figure metadata.
- code/: plotting code included in this Supplementary Data package.
- utils/: shared deterministic model utilities used by the plotting code.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
- Supplementary Figure 21: Load shedding and runtime are scenario-run observations; line temperature is a scenario-line observation.
- Supplementary Figure 22: Load shedding is a scenario-run observation; line temperature is a scenario-line observation.

Reproduction
------------
  python code/plot_ieee_benchmark_figure.py --source-dir data/Supplementary_Fig_21_ieee_thermal_sensitivity/data --output-dir reproduced_artwork/Supplementary_Fig_21

  python code/plot_si_distribution_panels.py --source-root data --output-root reproduced_distribution_artwork
  python code/plot_ieee_benchmark_figure.py --source-dir data/Supplementary_Fig_22_ieee_weather_sensitivity/data --output-dir reproduced_artwork/Supplementary_Fig_22

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
All compact data files for the listed figures.
