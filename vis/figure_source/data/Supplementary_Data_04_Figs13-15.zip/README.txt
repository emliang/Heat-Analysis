Supplementary Data for Supplementary Figure 13, Supplementary Figure 14, Supplementary Figure 15
================================================================================================

Manuscript reference: NENERGY-24102996D
Display item: Supplementary Figure 13, Supplementary Figure 14, Supplementary Figure 15

Package structure
-----------------
- data/: numerical data and figure metadata.
- code/: plotting code included in this Supplementary Data package.
- utils/: shared deterministic model utilities used by the plotting code.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
- Supplementary Figure 13: Load shedding and runtime are observations for each of the same 480 scenarios; line temperature and available capacity are scenario-line observations for those scenarios.
- Supplementary Figure 14: Load shedding is a scenario observation; line temperature and available capacity are scenario-line observations. Map tables contain selected illustrative heatwave snapshots.
- Supplementary Figure 15: Load shedding sensitivities are scenario observations; line temperature and available capacity are scenario-line observations. Distribution panels show medians, interquartile ranges, 1.5-IQR whiskers and arithmetic means; outlier markers are not displayed.

Reproduction
------------
  python code/plot_si_distribution_panels.py --source-root data --output-root reproduced_distribution_artwork

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
All compact data files for the listed figures.
