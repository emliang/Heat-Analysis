Source Data for Main Figure 6
=============================

Manuscript reference: NENERGY-24102996D
Display item: Main Figure 6

Package structure
-----------------
- data/: numerical data and figure metadata.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
Each plotted value is one reference-country load-shedding observation for an aligned projected hourly heatwave scenario and represented interconnection configuration.

Reproduction
------------
The plotting code is maintained in the project repository (https://emliang.github.io/Heat-Analysis/). Before running the command, set HEAT_ANALYSIS_ROOT to the root of a local checkout, for example:

  export HEAT_ANALYSIS_ROOT=/path/to/HeatAnalysis

  conda run --no-capture-output -n HEAT python "${HEAT_ANALYSIS_ROOT:?Set HEAT_ANALYSIS_ROOT to the HeatAnalysis checkout}/nature_final_materials/publication_pipeline/code/plotting/plot_main_figure_06.py" --source-dir data --pdf reproduced/Fig_6.pdf --png reproduced/Fig_6.png

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Source Data for Fig. 6 - Cross-border load-shedding comparison
=================================================================

Panels a and b contain one load-shedding observation for each of 480
aligned projected hourly heatwave scenarios in every displayed Spain
or France interconnection setting at 1% annual load growth. Load shedding
is measured for the reference country and normalised by its matched
single-country demand. The alignment table records the same 480 scenarios
used in each comparison. The summary table records the displayed box, whisker, median
and mean statistics. Outlier points are not drawn, but no observations are
removed from the Source Data or density estimates.

The package is derived from the verified Supplementary cross-border data.
No OPF, weather generation or other simulation is rerun.
