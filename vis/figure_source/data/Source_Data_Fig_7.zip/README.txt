Source Data for Main Figure 7
=============================

Manuscript reference: NENERGY-24102996D
Display item: Main Figure 7

Package structure
-----------------
- data/: numerical data and figure metadata.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
The package contains national hourly profiles, gridded spatial weather values and sampled regional hourly profiles for the displayed projected heatwave examples.

Reproduction
------------
The plotting code is maintained in the project repository (https://emliang.github.io/Heat-Analysis/). Before running the command, set HEAT_ANALYSIS_ROOT to the root of a local checkout, for example:

  export HEAT_ANALYSIS_ROOT=/path/to/HeatAnalysis

  conda run --no-capture-output -n HEAT python "${HEAT_ANALYSIS_ROOT:?Set HEAT_ANALYSIS_ROOT to the HeatAnalysis checkout}/nature_final_materials/publication_pipeline/code/plotting/plot_main_figure_07.py" --source-dir data --pdf reproduced/Fig_7.pdf --png reproduced/Fig_7.png

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Source Data for Fig. 7 - Projected heatwave generation in Spain
=================================================================

Panel a contains the four displayed national spatial-mean hourly
temperature profiles. Panel b contains the four displayed spatial
temperature fields. Panel c contains the three displayed sampled bus
regions, each with one future-reference profile and five projected
heatwave profiles. Fig7_display_rules.json records the selected regions,
dates, snapshot hour, colour range and original common regional axis.

The exporter consumes the verified compact Spanish weather package. It
does not copy NetCDF archives or rerun weather/heatwave generation.
