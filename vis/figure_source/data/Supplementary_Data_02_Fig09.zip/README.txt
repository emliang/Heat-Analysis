Supplementary Data for Supplementary Figure 9
=============================================

Manuscript reference: NENERGY-24102996D
Display item: Supplementary Figure 9

Package structure
-----------------
- data/: numerical data and figure metadata.
- code/: plotting code included in this Supplementary Data package.
- utils/: shared deterministic model utilities used by the plotting code.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
- Supplementary Figure 9: Load shedding is one value per scenario and country; line temperature and available capacity are scenario-line observations. Countries use their own 480 projected heatwave scenarios rather than date-aligned scenarios.

Reproduction
------------
  python code/plot_si_distribution_panels.py --source-root data --output-root reproduced_distribution_artwork

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
All compact data files for the listed figures.
