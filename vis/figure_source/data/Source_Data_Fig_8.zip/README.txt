Source Data for Main Figure 8
=============================

Manuscript reference: NENERGY-24102996D
Display item: Main Figure 8

Package structure
-----------------
- data/: numerical data and figure metadata.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
Panel a contains daily demand-calibration observations and fitted values; panels b-c contain deterministic generator-derating and conductor heat-balance values and parameters.

Reproduction
------------
The plotting code is maintained in the project repository (https://emliang.github.io/Heat-Analysis/). Before running the command, set HEAT_ANALYSIS_ROOT to the root of a local checkout, for example:

  export HEAT_ANALYSIS_ROOT=/path/to/HeatAnalysis

  conda run --no-capture-output -n HEAT python "${HEAT_ANALYSIS_ROOT:?Set HEAT_ANALYSIS_ROOT to the HeatAnalysis checkout}/nature_final_materials/publication_pipeline/code/plotting/plot_main_figure_08.py" --project-root "$HEAT_ANALYSIS_ROOT" --source-dir data --pdf reproduced/Fig_8.pdf --png reproduced/Fig_8.png

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Source Data for Fig. 8 - Heatwave effects on demand, generation and transmission
================================================================================

Panel a contains one row per valid day in the Spanish demand-calibration
record, the corresponding fitted values, the two displayed fitted curves,
model parameters and validation statistics. Demand is a daily average.

Panel b contains the numerical values of the four displayed generator
derating curves and their formula definitions.

Panel c records the corrected conductor model, ambient-weather settings,
grid-generation rules and displayed 90 C thermal-limit contour. The dense
deterministic conductor-temperature matrix is generated in memory from the
heat-balance equation and is intentionally not duplicated in this package.

No power-flow, heatwave or calibration simulation is run by this exporter.
All data derive from the verified Supplementary component packages.
