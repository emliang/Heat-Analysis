Source Data for Extended Data Figure 2
======================================

Manuscript reference: NENERGY-24102996D
Display item: Extended Data Figure 2

Package structure
-----------------
- data/: numerical data and figure metadata.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
Displayed units are represented buses, represented AC branches and gridded weather cells within nine selected spatial snapshots.

Reproduction
------------
The plotting code is maintained in the project repository (https://emliang.github.io/Heat-Analysis/). Before running the command, set HEAT_ANALYSIS_ROOT to the root of a local checkout, for example:

  export HEAT_ANALYSIS_ROOT=/path/to/HeatAnalysis

  conda run --no-capture-output -n HEAT python "${HEAT_ANALYSIS_ROOT:?Set HEAT_ANALYSIS_ROOT to the HeatAnalysis checkout}/nature_final_materials/publication_pipeline/code/plotting/plot_extended_data_figures.py" --source-dir data --figure 2 --output-pdf reproduced/Extended_Data_Fig_2.pdf --output-png reproduced/Extended_Data_Fig_2.png

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Source Data for Extended Data Fig. 2 - Spanish cross-border maps
=================================================================

Scope and displayed units
-------------------------
The package contains nine author-selected illustrative 13:00 snapshots: Spain,
Spain+Portugal and Spain+France in 2026, 2028 and 2030. All use 1% annual load
growth and 80% initial storage state of charge. The snapshots are not
algorithmically selected peaks. All nine records have solver_status=1. No
statistical aggregation or hypothesis test is applied.

The plotted units are one represented bus, one represented AC branch and one
gridded weather cell within one selected spatial snapshot. Only buses in Spain,
the reference country, can receive a displayed load-shedding marker; the full
represented network for each configuration is retained.

Files, columns and units
------------------------
- ExtendedDataFig2_map_snapshots.csv: snapshot/configuration IDs, display order,
  future date/hour, historical event date, original artwork path and selection
  basis.
- ExtendedDataFig2_map_bus_observations.csv: snapshot/configuration/bus IDs,
  active_demand_mw, load_shedding_mw,
  load_shedding_percent_of_reference_demand and display_marker.
- ExtendedDataFig2_map_branch_observations.csv: snapshot/configuration/branch IDs
  and line_temperature_c.
- ExtendedDataFig2_map_weather_fields.csv.gz: snapshot/grid indices,
  longitude_plot, latitude_plot and air_temperature_c.
- ExtendedDataFig2_represented_network_buses.csv: bus ID, coordinates, country
  and is_reference_country for every represented configuration.
- ExtendedDataFig2_represented_network_lines.csv: branch ID, endpoints,
  endpoint countries, is_reference_internal and line geometry.
- ExtendedDataFig2_record_provenance.csv: exact OPF and weather record paths,
  byte counts, SHA-256 hashes and solver_status for each snapshot.
- ExtendedDataFig2_plot_metadata.json: load-growth, storage, temperature scales,
  marker scope, observation units and plotting settings.
- input_provenance.csv and manifest.json: package provenance and input/output
  hashes.

Filters and source record pattern
---------------------------------
No simulation is rerun and no value filter is applied. The exporter consumes
the verified Supplementary Fig. 26 compact component. Exact result/weather
records follow the paths in ExtendedDataFig2_record_provenance.csv; input files
and SHA-256 hashes are also recorded in input_provenance.csv and manifest.json.

Export:
  conda run --no-capture-output -n HEAT python nature_final_materials/publication_pipeline/code/exporters/export_extended_data_figures.py --pipeline-root nature_final_materials/publication_pipeline --figure 2
Plot:
  conda run --no-capture-output -n HEAT python nature_final_materials/publication_pipeline/code/plotting/plot_extended_data_figures.py --pipeline-root nature_final_materials/publication_pipeline --figure 2
