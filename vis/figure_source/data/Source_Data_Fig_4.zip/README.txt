Source Data for Main Figure 4
=============================

Manuscript reference: NENERGY-24102996D
Display item: Main Figure 4

Package structure
-----------------
- data/: numerical data and figure metadata.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
Panels a, c and d contain scenario-level observations; panel b contains scenario-line observations over the represented Spanish grid.

Reproduction
------------
The plotting code is maintained in the project repository (https://emliang.github.io/Heat-Analysis/). Before running the command, set HEAT_ANALYSIS_ROOT to the root of a local checkout, for example:

  export HEAT_ANALYSIS_ROOT=/path/to/HeatAnalysis

  conda run --no-capture-output -n HEAT python "${HEAT_ANALYSIS_ROOT:?Set HEAT_ANALYSIS_ROOT to the HeatAnalysis checkout}/nature_final_materials/publication_pipeline/code/plotting/plot_main_figure_04.py" --source-dir data --pdf reproduced/Fig_4.pdf --png reproduced/Fig_4.png

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Source Data for Fig. 4 - Operating sensitivity
================================================

Panel a contains one load-shedding observation per projected hourly
heatwave scenario and model setting. Panel b contains line-temperature
observations for every scenario and represented branch; the compressed
wide table retains one row per scenario-branch pair. Panels c and d
contain one load-shedding observation per scenario for each year and
load-growth or initial-storage-state-of-charge setting. All direct
comparisons use the same 480 scenarios.

Boxes span the first to third quartile; dark-grey lines show medians;
whiskers use Tukey's 1.5-IQR rule; dark-red points show arithmetic means.
Outlier points are not drawn, but no observations are removed from the
Source Data or panel a-b density estimates.

The package is derived from the verified Spain operating-sensitivity
Supplementary package. No simulation is rerun.
