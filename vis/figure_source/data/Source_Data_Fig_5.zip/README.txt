Source Data for Main Figure 5
=============================

Manuscript reference: NENERGY-24102996D
Display item: Main Figure 5

Package structure
-----------------
- data/: numerical data and figure metadata.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
Panels a-b contain scenario-country observations; panel c contains scenario-line observations for each represented national grid configuration.

Reproduction
------------
The plotting code is maintained in the project repository (https://emliang.github.io/Heat-Analysis/). Before running the command, set HEAT_ANALYSIS_ROOT to the root of a local checkout, for example:

  export HEAT_ANALYSIS_ROOT=/path/to/HeatAnalysis

  conda run --no-capture-output -n HEAT python "${HEAT_ANALYSIS_ROOT:?Set HEAT_ANALYSIS_ROOT to the HeatAnalysis checkout}/nature_final_materials/publication_pipeline/code/plotting/plot_main_figure_05.py" --source-dir data --pdf reproduced/Fig_5.pdf --png reproduced/Fig_5.png

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
Source Data for main Figure 5

Fig5ab_scenario_observations.csv contains the complete plotted scenario populations for panels a and b.
Fig5c_available_capacity_observations.csv.gz contains the complete scenario-by-internal-AC-line population plotted in panel c.
The country scenario sets are intentionally country-specific. The exporter consumes the verified Supplementary Figure 15 component and does not rerun simulations or duplicate upstream NPY records.
