Supplementary Data for Supplementary Figure 1, Supplementary Figure 2, Supplementary Figure 3, Supplementary Figure 4, Supplementary Figure 5, Supplementary Figure 6, Supplementary Figure 7, Supplementary Figure 8
=====================================================================================================================================================================================================================

Manuscript reference: NENERGY-24102996D
Display item: Supplementary Figure 1, Supplementary Figure 2, Supplementary Figure 3, Supplementary Figure 4, Supplementary Figure 5, Supplementary Figure 6, Supplementary Figure 7, Supplementary Figure 8

Package structure
-----------------
- data/: numerical data and figure metadata.
- code/: plotting code included in this Supplementary Data package.
- utils/: shared deterministic model utilities used by the plotting code.
- manifest.json: file-level rows, columns, sizes and SHA-256 hashes.
- environment.txt: verified plotting environment.

Observation unit
----------------
- Supplementary Figure 1: Rows describe represented buses, lines, links and capacity assets.
- Supplementary Figure 2: National profiles are hourly means across all bus regions in the represented Spanish grid; regional and spatial rows support the displayed examples.
- Supplementary Figure 3: National profiles are hourly means across all bus regions in the represented Spanish grid; regional and spatial rows support the displayed examples.
- Supplementary Figure 4: National profiles are hourly means across all bus regions in the represented Spanish grid; regional and spatial rows support the displayed examples.
- Supplementary Figure 5: Each row is an hourly mean temperature across all bus regions in the represented national grid; country identifies the corresponding panel.
- Supplementary Figure 6: Each plotted observation is a valid daily-average demand value derived from 24 positive hourly load values; the fitted daily relationship is later resolved to hourly demand using historical hot-day hourly ratios.
- Supplementary Figure 7: The curves are generated deterministically from the listed model definitions and temperature-grid rule; no dense generated curve matrix is stored.
- Supplementary Figure 8: The surfaces are generated deterministically from the listed conductor, weather and grid rules; no dense generated surface matrix is stored.

Reproduction
------------
  python code/plot_spain_grid_configuration.py --source-dir data/Supplementary_Fig_01_spain_grid_configuration/data --pdf reproduced_artwork/Supplementary_Fig_01.pdf --png reproduced_artwork/Supplementary_Fig_01.png
  python code/plot_heatwave_weather_figure.py --source-dir data/Supplementary_Fig_02_spain_temperature/data --output-dir reproduced_artwork/Supplementary_Fig_02
  python code/plot_heatwave_weather_figure.py --source-dir data/Supplementary_Fig_03_spain_solar/data --output-dir reproduced_artwork/Supplementary_Fig_03
  python code/plot_heatwave_weather_figure.py --source-dir data/Supplementary_Fig_04_spain_wind/data --output-dir reproduced_artwork/Supplementary_Fig_04
  python code/plot_country_temperature_profiles.py --source-dir data/Supplementary_Fig_05_country_temperature_profiles/data --output-dir reproduced_artwork/Supplementary_Fig_05
  python code/plot_demand_calibration.py --source-dir data/Supplementary_Fig_06_demand_calibration/data --artwork-dir reproduced_artwork/Supplementary_Fig_06 --preview-dir reproduced_artwork/Supplementary_Fig_06_preview
  python code/plot_generator_derating.py --source-dir data/Supplementary_Fig_07_generator_derating/data --pdf reproduced_artwork/Supplementary_Fig_07.pdf --png reproduced_artwork/Supplementary_Fig_07.png
  python code/plot_conductor_heat_flow.py --project-root . --source-dir data/Supplementary_Fig_08_conductor_heat_flow/data --artwork-dir reproduced_artwork/Supplementary_Fig_08 --preview-dir reproduced_artwork/Supplementary_Fig_08_preview

The commands read the packaged data using the cited plotting code; they do not rerun the power-flow simulations.

Package-specific notes
----------------------
All compact data files for the listed figures.
